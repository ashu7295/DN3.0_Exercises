package com.example.projection;

public class EmployeeProjection {
    String getName(){
        return "John Doe";
    }
    Double getSalary(){
        return 1200.0;
    }
}
